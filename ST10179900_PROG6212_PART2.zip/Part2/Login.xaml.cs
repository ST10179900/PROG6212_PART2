﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;
using XSystem.Security.Cryptography;

namespace Part2
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        private bool Check(string Username, string Password)
        {
            String connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\lab_services_student\\Downloads\\poe\\Part2\\NewStudent.mdf;Integrated Security=True";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();




                //SHA1 Cryptography
                var sha1 = new SHA1CryptoServiceProvider();
                var bytePassword = Encoding.ASCII.GetBytes(Password);
                var sha1data = sha1.ComputeHash(bytePassword);
                var hashedPassword = ASCIIEncoding.GetEncoding(0).GetString(sha1data);

                string query = "SELECT COUNT(*) FROM dbo.Infoo WHERE Username = @Username AND Password = @Password";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", Username);
                    cmd.Parameters.AddWithValue("@Password", hashedPassword);
                    int result = Convert.ToInt32(cmd.ExecuteScalar());
                    return result == 1;
                }
            }
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow newRegister = new MainWindow();
           

            string Username = txtUser.Text;
            string Password = txtPass.Text;

            if (Check(Username, Password))
            {
                MessageBox.Show("Login successful");
                Close();
            }
            else
            {
                MessageBox.Show("Error");
            }

        }
    }
}
