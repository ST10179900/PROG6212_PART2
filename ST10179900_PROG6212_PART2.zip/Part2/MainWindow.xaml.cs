﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using XSystem.Security.Cryptography;

namespace Part2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //public List<Details> detail = new List<Details>();

        //private void btnReg_Click(object sender, RoutedEventArgs e)
        //{
        //    string Username = txtUser.Text;
        //    string Password = txtPass.Text;




        //    String connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\lab_services_student\\Downloads\\poe\\Part2\\NewStudent.mdf;Integrated Security=True";

        //    using (SqlConnection conn = new SqlConnection(connectionString))
        //    {
        //        conn.Open();




        //        //SHA1 Cryptography
        //        var sha1 = new SHA1CryptoServiceProvider();
        //        var bytePassword = Encoding.ASCII.GetBytes(Password);
        //        var sha1data = sha1.ComputeHash(bytePassword);
        //        var hashedPassword = ASCIIEncoding.GetEncoding(0).GetString(sha1data);

        //        string sqlQuery = $"Insert into dbo.Infoo (Username, Password) VALUES('{Username}','{hashedPassword}')";

        //        SqlCommand cmd = new SqlCommand(sqlQuery, conn);

        //        cmd.ExecuteNonQuery();
        //        conn.Close();

        //    }
        //}

        private void btnLog_Click(object sender, RoutedEventArgs e)
        {
            Login Login = new Login();
            Login.Show();

        }

        private void btnReg_Click_1(object sender, RoutedEventArgs e)
        {
            string Username = txtUser.Text;
            string Password = txtPass.Text;




            String connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\lab_services_student\\Downloads\\poe\\Part2\\NewStudent.mdf;Integrated Security=True";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();




                //SHA1 Cryptography
                var sha1 = new SHA1CryptoServiceProvider();
                var bytePassword = Encoding.ASCII.GetBytes(Password);
                var sha1data = sha1.ComputeHash(bytePassword);
                var hashedPassword = ASCIIEncoding.GetEncoding(0).GetString(sha1data);

                string sqlQuery = $"Insert into dbo.Infoo (Username, Password) VALUES('{Username}','{hashedPassword}')";

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                cmd.ExecuteNonQuery();
                conn.Close();

            }
        }
    }
}
