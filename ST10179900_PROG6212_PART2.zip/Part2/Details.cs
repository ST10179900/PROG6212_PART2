﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part2
{
    public class Details
    {
        private string username;
        private string password;

        public string Username { get; set; }
        public string Password { get; set; }
    }
}
